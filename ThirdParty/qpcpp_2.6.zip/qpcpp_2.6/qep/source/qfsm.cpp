/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qfsm.h"
#include "qep_pkg.h"

//............................................................................
char const *QFsm::getVersion() {
    return "QFSM 2.6; (c) 2002-2004 Quantum Leaps";
}
//............................................................................
QFsm::~QFsm() {                                                // virtual Xtor
}
//............................................................................
void QFsm::init(QEvent const *) {
    dispatch(&pkgStdEvt[Q_ENTRY_SIG]);
}
//............................................................................
void QFsm::tran(QFsmState target) {
    dispatch(&pkgStdEvt[Q_EXIT_SIG]);
    myState = target;                                  // change current state
    dispatch(&pkgStdEvt[Q_ENTRY_SIG]);
}
