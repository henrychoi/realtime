/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "qhsm.h"
#include "qep_pkg.h"

DEFINE_THIS_FILE;
                                                               // helper macro
#define TRIGGER(state_, sig_) (QState)((this->*(state_))(&pkgStdEvt[sig_]))

void QHsm::tran(QState target) {
    REQUIRE(target != &QHsm::top);                // cannot target "top" state
    QState entry[7], p, q, s, *e, *lca;
    for (s = myState; s != mySource;) {
        ASSERT(s != 0);                       // we are about to dereference s
        QState t = TRIGGER(s, Q_EXIT_SIG);
        if (t != 0) {         // exit action unhandled, t points to superstate
            s = t;
        }
        else {                       // exit action handled, elicit superstate
            s = TRIGGER(s, Q_EMPTY_SIG);
        }
    }

    *(e = &entry[0]) = 0;
    *(++e) = target;                                 // assume entry to target

                          // (a) check mySource == target (transition to self)
    if (mySource == target) {
        TRIGGER(mySource, Q_EXIT_SIG);                          // exit source
        goto inLCA;
    }
                                        // (b) check mySource == target->super
    p = TRIGGER(target, Q_EMPTY_SIG);
    if (mySource == p) {
        goto inLCA;
    }
                   // (c) check mySource->super == target->super (most common)
    q = TRIGGER(mySource, Q_EMPTY_SIG);
    if (q == p) {
        TRIGGER(mySource, Q_EXIT_SIG);                          // exit source
        goto inLCA;
    }
                                        // (d) check mySource->super == target
    if (q == target) {
        TRIGGER(mySource, Q_EXIT_SIG);                          // exit source
        --e;                                           // do not enter the LCA
        goto inLCA;
    }
            // (e) check rest of mySource == target->super->super... hierarchy
    *(++e) = p;
    for (s = TRIGGER(p, Q_EMPTY_SIG); s != 0;
        s = TRIGGER(s, Q_EMPTY_SIG)) {
        if (mySource == s) {
            goto inLCA;
        }
        *(++e) = s;
    }
    TRIGGER(mySource, Q_EXIT_SIG);                              // exit source
               // (f) check rest of mySource->super == target->super->super...
    for (lca = e; *lca != 0; --lca) {
        if (q == *lca) {
            e = lca - 1;                               // do not enter the LCA
            goto inLCA;
        }
    }
                  // (g) check each mySource->super->super..for each target...
    for (s = q; s != 0; s = TRIGGER(s, Q_EMPTY_SIG)) {
        for (lca = e; *lca != 0; --lca) {
            if (s == *lca) {
                e = lca - 1;                          // do not enter the LCA
                goto inLCA;
            }
        }
        TRIGGER(s, Q_EXIT_SIG);                                      // exit s
    }
    ASSERT(0);                                                // malformed HSM

inLCA:                         // now we are in the LCA of mySource and target
    ASSERT(e < &entry[DIM(entry)]);                 // new entry e must fit in
    while ((s = *e--) != 0) {      // retrace the entry path in reverse order
        TRIGGER(s, Q_ENTRY_SIG);                                    // enter s
    }
    myState = target;                                  // update current state
    while (TRIGGER(target, Q_INIT_SIG) == 0) {
                                // initial transition must go *one* level deep
        ASSERT(target == TRIGGER(myState, Q_EMPTY_SIG));
        target = myState;
        TRIGGER(target, Q_ENTRY_SIG);                          // enter target
    }
}
