/*****************************************************************************
* Product:  Quantum Calculator Example
* Version:  Compatible with QEP/C++ 2.6.xx
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef calc_h
#define calc_h

#include "qhsm.h"
#include <windows.h>

struct CalcEvt : public QEvent {
    int keyId;                                      // ID of the key depressed
};

class Calc : public QHsm {                         // calculator state machine
public:
    Calc() : QHsm((QPseudoState)initial) {}
private:
    void initial(QEvent const *e);
    QSTATE calc(QEvent const *e);
    QSTATE ready(QEvent const *e);
    QSTATE result(QEvent const *e);
    QSTATE begin(QEvent const *e);
    QSTATE negated1(QEvent const *e);
    QSTATE operand1(QEvent const *e);
    QSTATE zero1(QEvent const *e);
    QSTATE int1(QEvent const *e);
    QSTATE frac1(QEvent const *e);
    QSTATE opEntered(QEvent const *e);
    QSTATE negated2(QEvent const *e);
    QSTATE operand2(QEvent const *e);
    QSTATE zero2(QEvent const *e);
    QSTATE int2(QEvent const *e);
    QSTATE frac2(QEvent const *e);
    QSTATE final(QEvent const *e);
    // helper methods...
    void clear();
    void insert(int keyId);
    void negate();
    void eval();
    void dispState(char const *s);
private:
    HWND myHwnd;                               // the calculator window handle
    char myDisplay[40];
    char *myIns;
    double myOperand1;
    double myOperand2;
    int myOperator;
    friend BOOL CALLBACK calcDlg(HWND hwnd, UINT iEvt,
                                 WPARAM wParam, LPARAM lParam);
};

#endif                                                               // calc_h
