/*****************************************************************************
* Product:  Quantum Calculator Example
* Version:  Compatible with QEP/C++ 2.6.xx
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "calc.h"
#include "resource.h"

#include <string.h>
#include <commctrl.h>
#include <stdio.h>

DEFINE_THIS_FILE;

enum { PRECISION = 14 };

static HINSTANCE locHinst;                                    // this instance
static HWND locHwnd;                                          // window handle
static Calc app;                     // instance of the Calculator application

//----------------------------------------------------------------------------
void Calc::clear() {
    myDisplay[0] = ' ';
    myDisplay[1] = '0';
    myDisplay[2] = '\0';
    myIns = &myDisplay[1];
    SetDlgItemText(myHwnd, IDC_DISPLAY, myDisplay);
}
//............................................................................
void Calc::insert(int keyId) {
    if (myIns < &myDisplay[PRECISION - 1]) {
        *myIns++ = (keyId == IDC_POINT) ? '.' : keyId - IDC_0 + '0';
        *myIns = '\0';
        SetDlgItemText(myHwnd, IDC_DISPLAY, myDisplay);
    }
}
//............................................................................
void Calc::negate() {
    myDisplay[0] = '-';
    SetDlgItemText(myHwnd, IDC_DISPLAY, myDisplay);
}
//............................................................................
void Calc::eval() {
    double r;
    switch (myOperator) {
        case IDC_PLUS:
            r = myOperand1 + myOperand2;
            break;
        case IDC_MINUS:
            r = myOperand1 - myOperand2;
            break;
        case IDC_MULT:
            r = myOperand1 * myOperand2;
            break;
        case IDC_DIVIDE:
            if (myOperand2 != 0.0) {
                r = myOperand1 / myOperand2;
            }
            else {
                MessageBox(myHwnd, "Cannot Divide by 0",
                    "Calculator", MB_OK);
                r = 0.0;
            }
            break;
        default:
            ASSERT(0);
    }
    if (-1.0e10 < r && r < 1.0e10) {
        sprintf(myDisplay, "%24.11g", r);
    }
    else {
        MessageBox(myHwnd, "Result out of range", "Calculator", MB_OK);
        clear();
    }
    SetDlgItemText(myHwnd, IDC_DISPLAY, myDisplay);
}
//............................................................................
void Calc::dispState(char const *s) {
    SetDlgItemText(myHwnd, IDC_STATE, s);
}
// HSM definition ------------------------------------------------------------
void Calc::initial(QEvent const *) {
    Q_INIT(&Calc::calc);
}
//............................................................................
QSTATE Calc::final(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            EndDialog(myHwnd, 0);
            return 0;
    }
    return (QSTATE)&Calc::top;
}
//............................................................................
QSTATE Calc::calc(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("calc");
            return 0;
        case Q_INIT_SIG:
            clear();
            Q_INIT(&Calc::ready);
            return 0;
        case IDC_C:
            clear();
            Q_TRAN(&Calc::calc);
            return 0;
        case TERMINATE:
            Q_TRAN(&Calc::final);
            return 0;
    }
    return (QSTATE)&Calc::top;
}
//............................................................................
QSTATE Calc::ready(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("ready");
            return 0;
        case Q_INIT_SIG:
            Q_INIT(&Calc::begin);
            return 0;
        case IDC_0:
            clear();
            Q_TRAN(&Calc::zero1);
            return 0;
        case IDC_1_9:
            clear();
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::int1);
            return 0;
        case IDC_POINT:
            clear();
            insert(IDC_0);
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac1);
            return 0;
        case IDC_OPER:
            sscanf(myDisplay, "%lf", &myOperand1);
            myOperator = ((CalcEvt *)e)->keyId;
            Q_TRAN(&Calc::opEntered);
            return 0;
    }
    return (QSTATE)&Calc::calc;
}
//............................................................................
QSTATE Calc::result(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("result");
            eval();
            return 0;
    }
    return (QSTATE)&Calc::ready;
}
//............................................................................
QSTATE Calc::begin(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("begin");
            return 0;
        case IDC_OPER:
            if (((CalcEvt *)e)->keyId == IDC_MINUS) {
                Q_TRAN(&Calc::negated1);
                return 0;                                     // event handled
            }
            else if (((CalcEvt *)e)->keyId == IDC_PLUS) {         // unary "+"
                return 0;                                     // event handled
            }
            break;                                         // event unhandled!
    }
    return (QSTATE)&Calc::ready;
}
//............................................................................
QSTATE Calc::negated1(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("negated1");
            negate();
            return 0;
        case IDC_CE:
            clear();
            Q_TRAN(&Calc::begin);
            return 0;
        case IDC_0:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::zero1);
            return 0;
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::int1);
            return 0;
        case IDC_POINT:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac1);
            return 0;
    }
    return (QSTATE)&Calc::calc;
}
//............................................................................
QSTATE Calc::negated2(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("negated2");
            negate();
            return 0;
        case IDC_CE:
            Q_TRAN(&Calc::opEntered);
            return 0;
        case IDC_0:
            Q_TRAN(&Calc::zero2);
            return 0;
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::int2);
            return 0;
        case IDC_POINT:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac2);
            return 0;
    }
    return (QSTATE)&Calc::calc;
}
//............................................................................
QSTATE Calc::operand1(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("operand1");
            return 0;
        case IDC_CE:
            clear();
            Q_TRAN(&Calc::begin);
            return 0;
        case IDC_OPER:
            sscanf(myDisplay, "%lf", &myOperand1);
            myOperator = ((CalcEvt *)e)->keyId;
            Q_TRAN(&Calc::opEntered);
            return 0;
    }
    return (QSTATE)&Calc::calc;
}
//............................................................................
QSTATE Calc::zero1(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("zero1");
            return 0;
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::int1);
            return 0;
        case IDC_POINT:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac1);
            return 0;
    }
    return (QSTATE)&Calc::operand1;
}
//............................................................................
QSTATE Calc::int1(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("int1");
            return 0;
        case IDC_0:
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            return 0;
        case IDC_POINT:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac1);
            return 0;
    }
    return (QSTATE)&Calc::operand1;
}
//............................................................................
QSTATE Calc::frac1(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("frac1");
            return 0;
        case IDC_0:
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            return 0;
    }
    return (QSTATE)&Calc::operand1;
}
//............................................................................
QSTATE Calc::opEntered(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("opEntered");
            return 0;
        case IDC_OPER:
            if (((CalcEvt *)e)->keyId == IDC_MINUS) {
                clear();
                Q_TRAN(&Calc::negated2);
            }
            return 0;
        case IDC_0:
            clear();
            Q_TRAN(&Calc::zero2);
            return 0;
        case IDC_1_9:
            clear();
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::int2);
            return 0;
        case IDC_POINT:
            clear();
            insert(IDC_0);
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac2);
            return 0;
    }
    return (QSTATE)&Calc::calc;
}
//............................................................................
QSTATE Calc::operand2(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("operand2");
            return 0;
        case IDC_CE:
            clear();
            Q_TRAN(&Calc::opEntered);
            return 0;
        case IDC_OPER:
            sscanf(myDisplay, "%lf", &myOperand2);
            eval();
            sscanf(myDisplay, "%lf", &myOperand1);
            myOperator = ((CalcEvt *)e)->keyId;
            Q_TRAN(&Calc::opEntered);
            return 0;
        case IDC_EQUALS:
            sscanf(myDisplay, "%lf", &myOperand2);
            Q_TRAN(&Calc::result);
            return 0;
    }
    return (QSTATE)&Calc::calc;
}
//............................................................................
QSTATE Calc::zero2(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("zero2");
            return 0;
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::int2);
            return 0;
        case IDC_POINT:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac2);
            return 0;
    }
    return (QSTATE)&Calc::operand2;
}
//............................................................................
QSTATE Calc::int2(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("int2");
            return 0;
        case IDC_0:
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            return 0;
        case IDC_POINT:
            insert(((CalcEvt *)e)->keyId);
            Q_TRAN(&Calc::frac2);
            return 0;
    }
    return (QSTATE)&Calc::operand2;
}
//............................................................................
QSTATE Calc::frac2(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            dispState("frac2");
            return 0;
        case IDC_0:
        case IDC_1_9:
            insert(((CalcEvt *)e)->keyId);
            return 0;
    }
    return (QSTATE)&Calc::operand2;
}
//============================================================================
extern "C" void onAssert__(char const *file, int line) {
    char str[160];
    sprintf(str, "Assertion failed in %s, line %d", file, line);
    MessageBox(locHwnd, str, "Calulator", MB_OK);
    exit(-1);
}
//............................................................................
BOOL CALLBACK calcDlg(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam) {
    CalcEvt e;
    switch (iMsg) {
        case WM_INITDIALOG: {
            app.myHwnd = locHwnd = hwnd;
            SendMessage(hwnd, WM_SETICON, (WPARAM)TRUE,
                (LPARAM)LoadIcon(locHinst, MAKEINTRESOURCE(IDI_QL)));
            app.init();                         // take the initial transition
            return TRUE;
        }
        case WM_COMMAND: {
            switch (e.keyId = LOWORD(wParam)) {
            case IDCANCEL:
                e.sig = TERMINATE;
                break;
            case IDC_1:
            case IDC_2:
            case IDC_3:
            case IDC_4:
            case IDC_5:
            case IDC_6:
            case IDC_7:
            case IDC_8:
            case IDC_9:
                e.sig = IDC_1_9;
                break;
            case IDC_PLUS:
            case IDC_MINUS:
            case IDC_MULT:
            case IDC_DIVIDE:
                e.sig = IDC_OPER;
                break;
            default:
                e.sig = e.keyId;
                break;
            }
            app.dispatch(&e);                             // take one RTC step
            return TRUE;
        }
    }
    return FALSE;
}
//............................................................................
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst,
                   PSTR cmdLine, int iCmdShow)
{
    InitCommonControls();                      // load common controls library
    locHinst = hInst;                                 // store instance handle
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, calcDlg);
    return 0;                      // exit application when the dialog returns
}

