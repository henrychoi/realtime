//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Calc.rc
//
#define TERMINATE                       100
#define IDD_DIALOG                      101
#define IDI_QL                          103
#define IDB_QL                          106
#define IDC_0                           1000
#define IDC_1                           1001
#define IDC_2                           1002
#define IDC_3                           1003
#define IDC_4                           1004
#define IDC_5                           1005
#define IDC_6                           1006
#define IDC_7                           1007
#define IDC_8                           1008
#define IDC_9                           1009
#define IDC_1_9                         1010
#define IDC_STATE                       1100
#define IDC_POINT                       1101
#define IDC_EQUAL                       1102
#define IDC_EQUALS                      1102
#define IDC_PLUS                        1103
#define IDC_MINUS                       1104
#define IDC_MULT                        1105
#define IDC_DIVIDE                      1106
#define IDC_OPER                        1107
#define IDC_PERCENT                     1108
#define IDC_C                           1109
#define IDC_CE                          1110
#define IDC_DISPLAY                     1111

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
