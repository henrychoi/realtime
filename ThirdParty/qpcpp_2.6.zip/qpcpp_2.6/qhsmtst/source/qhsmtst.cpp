/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "qhsm.h"
#include "qhsmtst.h"

#include <stdlib.h>
#include <stdio.h>

DEFINE_THIS_FILE;

//............................................................................
void QHsmTst::initial(QEvent const *) {
    printf("top-INIT;");
    myFoo = 0;                           // initialize extended state variable
    Q_INIT(&QHsmTst::s0);                                // initial transition
}
//............................................................................
QSTATE QHsmTst::s0(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            printf("s0-ENTRY;");
            return 0;
        }
        case Q_EXIT_SIG: {
            printf("s0-EXIT;");
            return 0;
        }
        case Q_INIT_SIG: {
            printf("s0-INIT;");
            Q_INIT(&QHsmTst::s1);
            return 0;
        }
        case E_SIG: {
            printf("s0-E;");
            Q_TRAN(&QHsmTst::s211);
            return 0;
        }
    }
    return (QSTATE)&QHsmTst::top;
}
//............................................................................
QSTATE QHsmTst::s1(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            printf("s1-ENTRY;");
            return 0;
        }
        case Q_EXIT_SIG: {
            printf("s1-EXIT;");
            return 0;
        }
        case Q_INIT_SIG: {
            printf("s1-INIT;");
            Q_INIT(&QHsmTst::s11);
            return 0;
        }
        case A_SIG: {
            printf("s1-A;");
            Q_TRAN(&QHsmTst::s1);
            return 0;
        }
        case B_SIG: {
            printf("s1-B;");
            Q_TRAN(&QHsmTst::s11);
            return 0;
        }
        case C_SIG: {
            printf("s1-C;");
            Q_TRAN(&QHsmTst::s2);
            return 0;
        }
        case D_SIG: {
            printf("s1-D;");
            Q_TRAN(&QHsmTst::s0);
            return 0;
        }
        case F_SIG: {
            printf("s1-F;");
            Q_TRAN(&QHsmTst::s211);
            return 0;
        }
    }
    return (QSTATE)&QHsmTst::s0;
}
//............................................................................
QSTATE QHsmTst::s11(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            printf("s11-ENTRY;");
            return 0;
        }
        case Q_EXIT_SIG: {
            printf("s11-EXIT;");
            return 0;
        }
        case G_SIG: {
            printf("s11-G;");
            Q_TRAN(&QHsmTst::s211);
            return 0;
        }
        case H_SIG: {                      // internal transition with a guard
            if (myFoo) {                           // test the guard condition
                printf("s11-H;");
                myFoo = 0;
                return 0;
            }
            break;
        }
    }
    return (QSTATE)&QHsmTst::s1;
}
//............................................................................
QSTATE QHsmTst::s2(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            printf("s2-ENTRY;");
            return 0;
        }
        case Q_EXIT_SIG: {
            printf("s2-EXIT;");
            return 0;
        }
        case Q_INIT_SIG: {
            printf("s2-INIT;");
            Q_INIT(&QHsmTst::s21);
            return 0;
        }
        case C_SIG: {
            printf("s2-C;");
            Q_TRAN(&QHsmTst::s1);
            return 0;
        }
        case F_SIG: {
            printf("s2-F;");
            Q_TRAN(&QHsmTst::s11);
            return 0;
        }
    }
    return (QSTATE)&QHsmTst::s0;
}
//............................................................................
QSTATE QHsmTst::s21(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            printf("s21-ENTRY;");
            return 0;
        }
        case Q_EXIT_SIG: {
            printf("s21-EXIT;");
            return 0;
        }
        case Q_INIT_SIG: {
            printf("s21-INIT;");
            Q_INIT(&QHsmTst::s211);
            return 0;
        }
        case B_SIG: {
            printf("s21-C;");
            Q_TRAN(&QHsmTst::s211);
            return 0;
        }
        case H_SIG: {                          // self transition with a guard
            if (!myFoo) {                          // test the guard condition
                printf("s21-H;");
                myFoo = !0;
                Q_TRAN(&QHsmTst::s21);                      // self transition
                return 0;
            }
            break;                           // break to return the superstate
        }
    }
    return (QSTATE)&QHsmTst::s2;                      // return the superstate
}
//............................................................................
QSTATE QHsmTst::s211(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            printf("s211-ENTRY;");
            return 0;
        }
        case Q_EXIT_SIG: {
            printf("s211-EXIT;");
            return 0;
        }
        case D_SIG: {
            printf("s211-D;");
            Q_TRAN(&QHsmTst::s21);
            return 0;
        }
        case G_SIG: {
            printf("s211-G;");
            Q_TRAN(&QHsmTst::s0);
            return 0;
        }
    }
    return (QSTATE)&QHsmTst::s21;
}

