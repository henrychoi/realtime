/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

enum { THINK_TIME = 7, EAT_TIME = 5 };

void Philosopher::initial(QEvent const *) {
    QF::subscribe(this, EAT_SIG);
    Q_INIT(&Philosopher::thinking);
}

QSTATE Philosopher::thinking(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            myTimer.fireIn(this, TIMEOUT_SIG, THINK_TIME);
            return 0;
        }
        case TIMEOUT_SIG: {
            Q_TRAN(&Philosopher::hungry);
            return 0;
        }
    }
    return (QSTATE)&Philosopher::top;
}

QSTATE Philosopher::hungry(QEvent const *e) {
    TableEvt *pe;
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            pe = Q_NEW(TableEvt, HUNGRY_SIG);
            pe->philNum = myNum;
            QF::publish(pe);
            return 0;
        }
        case EAT_SIG: {
            if (((TableEvt *)e)->philNum == myNum) {
                Q_TRAN(&Philosopher::eating);
            }
            return 0;
        }
    }
    return (QSTATE)&Philosopher::top;
}

QSTATE Philosopher::eating(QEvent const *e) {
    TableEvt *pe;
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            myTimer.fireIn(this, TIMEOUT_SIG, EAT_TIME);
            return 0;
        }
        case TIMEOUT_SIG: {
            Q_TRAN(&Philosopher::thinking);
            return 0;
        }
        case Q_EXIT_SIG: {
            pe = Q_NEW(TableEvt, DONE_SIG);
            pe->philNum = myNum;
            QF::publish(pe);
            return 0;
        }
    }
    return (QSTATE)&Philosopher::top;
}

#define RIGHT(n_) (((n_) + (N - 1)) % N)
#define LEFT(n_)  (((n_) + 1) % N)
enum { FREE = 0, USED = !0 };

void Table::initial(QEvent const *) {
    QF::subscribe(this, HUNGRY_SIG);
    QF::subscribe(this, DONE_SIG);
    for (unsigned n = 0; n < N; ++n) {
        myFork[n] = FREE;
        isHungry[n] = 0;
    }
    Q_INIT(&Table::serving);
}

QSTATE Table::serving(QEvent const *e) {
    unsigned n, m;
    TableEvt *pe;
    switch (e->sig) {
        case HUNGRY_SIG: {
            n = ((TableEvt *)e)->philNum;
            ASSERT(n < N && !isHungry[n]);
            printf("Philospher %1d is hungry\n", n);
            m = LEFT(n);
            if (myFork[m] == FREE && myFork[n] == FREE) {
                myFork[m] = myFork[n] = USED;
                pe = Q_NEW(TableEvt, EAT_SIG);
                pe->philNum = n;
                QF::publish(pe);
                printf("Philospher %1d is eating\n", n);
            }
            else {
                isHungry[n] = 1;
            }
            return 0;
        }
        case DONE_SIG: {
            n = ((TableEvt *)e)->philNum;
            ASSERT(n < N);
            printf("Philospher %1d is thinking\n", n);
            myFork[LEFT(n)] = myFork[n] = FREE;
            m = RIGHT(n);                          // check the right neighbor
            if (isHungry[m] && myFork[m] == FREE) {
                myFork[n] = myFork[m] = USED;
                isHungry[m] = 0;
                pe = Q_NEW(TableEvt, EAT_SIG);
                pe->philNum = m;
                QF::publish(pe);
                printf("Philospher %1d is eating\n", m);
            }
            m = LEFT(n);                            // check the left neighbor
            n = LEFT(m);
            if (isHungry[m] && myFork[n] == FREE) {
                myFork[m] = myFork[n] = USED;
                isHungry[m] = 0;
                pe = Q_NEW(TableEvt, EAT_SIG);
                pe->philNum = m;
                QF::publish(pe);
                printf("Philospher %1d is eating\n", m);
            }
            return 0;
        }
    }
    return (QSTATE)&Table::top;
}
