/*****************************************************************************
* Product:  QF/C++ 2.6.xx port to uC/OS-II under DOS with Borland C++ 3.1
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include "qassert.h"
#include "port.h"
extern "C" {
    #include "includes.h"                      // master uC/OS-II include file
    //#include "pc.h"
}
DEFINE_THIS_FILE;

//............................................................................
enum {                                  // we need to add some more signals...
    KBD_SIG = MAX_SIG,
    MMAX_SIG
};

//----------------------------------------------------------------------------
struct KbdEvt : public QEvent {
    unsigned char key;
};

//----------------------------------------------------------------------------
class KbdMgr : public QActive {                            // keyboard manager
public:
    KbdMgr() : QActive((QPseudoState)&KbdMgr::initial) {}
protected:
    void initial(QEvent const *e);                      // initial pseudostate
    QSTATE active(QEvent const *e);
};

//............................................................................
void KbdMgr::initial(QEvent const *) {
    QF::subscribe(this, KBD_SIG);
    Q_INIT(&KbdMgr::active);
}
//............................................................................
QSTATE KbdMgr::active(QEvent const *e) {
    switch (e->sig) {
        case KBD_SIG:
            if (((KbdEvt const *)e)->key == '\033') {              // ESC key?
                PC_DOSReturn();                               // Return to DOS
            }
            return 0;
   }
   return (QSTATE)&KbdMgr::top;
}
//............................................................................
static Table aTable;
static Philosopher aPhil[N] = { 0, 1, 2, 3, 4 };
static KbdMgr aKbdMgr;
static QEvent *tableQueueSto[N];
static QEvent *philQueueSto[N][N];
static QEvent *kbdMgrQueueSto[1];
static QSubscrList subscrSto[MMAX_SIG];
static TableEvt regPoolSto[N*N];

static int TableStk[256];                 // stack for the Table active object
static int PhilosopherStk[N][256];              // stacks for the philosophers
static int kbdMgrStk[256];                   // stack for the keyboard menager

//............................................................................
void onAssert__(char const *file, int line) {
    fprintf(stderr, "Assertion failed in %s, line %d", file, line);
    PC_DOSReturn();                                        /* Return to DOS */
}
//............................................................................
void OSTimeTickHook(void) {
    QF::tick();
    int key;
    if (PC_GetKey(&key)) {                      // See if key has been pressed
        KbdEvt *pe = Q_NEW(KbdEvt, KBD_SIG);
        pe->key = (unsigned char)key;
        QF::publish(pe);
    }
}
//............................................................................
void OSTaskCreateHook (OS_TCB *tcb) {
}
//............................................................................
void OSTaskDelHook (OS_TCB *tcb) {
}
//............................................................................
void OSTaskSwHook (void) {
}
//............................................................................
void OSTaskStatHook (void) {
}
//............................................................................
main() {
    OSInit();                                           // initialize uC/OS-II
    PC_DOSSaveReturn();                   // Save environment to return to DOS
    PC_VectSet(uCOS, OSCtxSw);                // install context switch vector
    OS_ENTER_CRITICAL();
    PC_VectSet(0x08, OSTickISR);          // Install uC/OS-II's clock tick ISR
    PC_SetTickRate(OS_TICKS_PER_SEC);                   // Reprogram tick rate
    OS_EXIT_CRITICAL();
    printf("Quantum DPP, built on %s at %s, libraries: %s\n",
           __DATE__, __TIME__, QF::getVersion());
    QF::init(subscrSto, DIM(subscrSto));
    QF::poolInit(regPoolSto, DIM(regPoolSto), sizeof(TableEvt));

    for (unsigned n = 0; n < N; ++n) {
        aPhil[n].start(n + 1, philQueueSto[n], DIM(philQueueSto[n]),
                       PhilosopherStk[n], DIM(PhilosopherStk[n]));
    }
    aTable.start(N + 1, tableQueueSto, DIM(tableQueueSto),
                 TableStk, DIM(TableStk));
    aKbdMgr.start(N + 2, kbdMgrQueueSto, DIM(kbdMgrQueueSto),
                  kbdMgrStk, DIM(kbdMgrStk));

    OSStart();                                           // Start multitasking
    return 0;         // OSStart never returns, this is to make compiler happy
}
