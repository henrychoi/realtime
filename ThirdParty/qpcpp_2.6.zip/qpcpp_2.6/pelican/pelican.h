//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by pelican.rc
//
#define IDS_APP_TITLE                   1
#define IDD_DIALOG                      101
#define IDI_QP                          103
#define IDI_QL                          103
#define IDB_RED                         105
#define IDB_YELLOW                      106
#define IDB_GREEN                       107
#define IDB_QL                          108
#define IDB_WALK                        109
#define IDB_DONT_WALK                   110
#define IDB_CROSSWALK                   112
#define IDC_PEDESTRIAN_WAITING          1011
#define IDC_RED                         1017
#define IDC_YELLOW                      1018
#define IDC_GREEN                       1019
#define IDC_WALK                        1020
#define IDB_BLANK                       1020
#define IDC_DONT_WALK                   1021
#define IDC_BLANK                       1023
#define IDC_STATE                       1100

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
