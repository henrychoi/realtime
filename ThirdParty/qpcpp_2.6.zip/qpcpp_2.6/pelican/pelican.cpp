/*****************************************************************************
* Product:  Pedestrian Light Controlled (PELICAN) Crossing Example
* Version:  Compatible with QEP/C++ 2.6.xx
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <windows.h>
#include <string.h>
#include <commctrl.h>
#include <stdio.h>

#include "qassert.h"
#include "qhsm.h"
#include "pelican.h"                                      // pelican resources

DEFINE_THIS_FILE;

//............................................................................
class Pelican : public QHsm {
    int  pedestrianFlashCtr_;
    HWND hWnd_;
public:
    Pelican();
protected:
    void initial(QEvent const *e);
    QSTATE operational(QEvent const *e);
    QSTATE vehiclesEnabled(QEvent const *e);
    QSTATE vehiclesGreen(QEvent const *e);
    QSTATE vehiclesGreenNoPed(QEvent const *e);
    QSTATE vehiclesGreenPedWait(QEvent const *e);
    QSTATE vehiclesGreenInt(QEvent const *e);
    QSTATE vehiclesYellow(QEvent const *e);
    QSTATE pedestriansEnabled(QEvent const *e);
    QSTATE pedestriansWalk(QEvent const *e);
    QSTATE pedestriansFlash(QEvent const *e);
    QSTATE off(QEvent const *e);
private:
    enum VehiclesSignal
    {
        RED, YELLOW, GREEN
    };
    enum PedestriansSignal
    {
        DONT_WALK, BLANK, WALK
    };

    void signalVehicles(enum VehiclesSignal sig);
    void signalPedestrians(enum PedestriansSignal sig);

    friend BOOL CALLBACK PelicanDlg(HWND hwnd, UINT iEvt,
        WPARAM wParam, LPARAM lParam);
};
//----------------------------------------------------------------------------
enum PelicanSignals
{
    OFF_SIG = Q_USER_SIG,
        PEDESTRIAN_WAITING_SIG,
        TIMEOUT_SIG
};
//............................................................................
enum PelicanTimeouts
{            // various timeouts in milliseconds
    VEHICLES_GREEN_MIN_TOUT = 8000,      // minimum green for vehicles
        VEHICLES_YELLOW_TOUT    = 2000,             // yellow for vehicles
        PEDESTRIANS_WALK_TOUT   = 4000,    // walking time for pedestrians
        PEDESTRIANS_FLASH_TOUT  = 500,       // flashing interval for ped.
        PEDESTRIANS_FLASH_NUM   = 3,         // number of flashes for ped.
};
//----------------------------------------------------------------------------
static Pelican app;
static HINSTANCE inst;                               // this instance
static HWND mainHwnd;                              // the main window
static char appName[] = "Pelican";

//............................................................................
Pelican::Pelican() : QHsm((QPseudoState)&Pelican::initial) {
    }
// HSM definition ------------------------------------------------------------
void Pelican::initial(QEvent const *e) {
    SendMessage(hWnd_, WM_SETICON, (WPARAM)TRUE,
                (LPARAM)LoadIcon(inst, MAKEINTRESOURCE(IDI_QP)));
    signalVehicles(RED);
    signalPedestrians(DONT_WALK);
    Q_INIT(&Pelican::operational);
}
//............................................................................
QSTATE Pelican::off(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            EndDialog(hWnd_, 0);
            return 0;
    }
    return (QSTATE)&QHsm::top;
}
//............................................................................
QSTATE Pelican::operational(QEvent const *e) {
    switch (e->sig) {
        case Q_INIT_SIG:
            Q_INIT(&Pelican::vehiclesEnabled);
            return 0;
        case OFF_SIG:
            Q_TRAN(&Pelican::off);
            return 0;
    }
    return (QSTATE)&QHsm::top;
}
//............................................................................
QSTATE Pelican::vehiclesEnabled(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            signalPedestrians(DONT_WALK);
            return 0;
        case Q_INIT_SIG:
            Q_INIT(&Pelican::vehiclesGreen);
            return 0;
    }
    return (QSTATE)&Pelican::operational;
}
//............................................................................
QSTATE Pelican::vehiclesGreen(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetTimer(hWnd_, 1, VEHICLES_GREEN_MIN_TOUT, 0);
            signalVehicles(GREEN);
            return 0;
        case Q_INIT_SIG:
            Q_INIT(&Pelican::vehiclesGreenNoPed);
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican::vehiclesGreenInt);
            return 0;
        case Q_EXIT_SIG:
            KillTimer(hWnd_, 1);                      // don't leak the timer!
            return 0;
    }
    return (QSTATE)&Pelican::vehiclesEnabled;
}
//............................................................................
QSTATE Pelican::vehiclesGreenNoPed(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(hWnd_, IDC_STATE, "vehiclesGreenNoPed");
            return 0;
        case PEDESTRIAN_WAITING_SIG:
            Q_TRAN(&Pelican::vehiclesGreenPedWait);
            return 0;
    }
    return (QSTATE)&Pelican::vehiclesGreen;
}
//............................................................................
QSTATE Pelican::vehiclesGreenPedWait(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(hWnd_, IDC_STATE, "vehiclesGreenPedWait");
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican::vehiclesYellow);
            return 0;
    }
    return (QSTATE)&Pelican::vehiclesGreen;
}
//............................................................................
QSTATE Pelican::vehiclesGreenInt(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(hWnd_, IDC_STATE, "vehiclesGreenInt");
            return 0;
        case PEDESTRIAN_WAITING_SIG:
            Q_TRAN(&Pelican::vehiclesYellow);
            return 0;
    }
    return (QSTATE)&Pelican::vehiclesEnabled;
}
//............................................................................
QSTATE Pelican::vehiclesYellow(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(hWnd_, IDC_STATE, "vehiclesYellow");
            SetTimer(hWnd_, 1, VEHICLES_YELLOW_TOUT, 0);
            signalVehicles(YELLOW);
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican::pedestriansEnabled);
            return 0;
        case Q_EXIT_SIG:
            KillTimer(hWnd_, 1);                      // don't leak the timer!
            return 0;
    }
    return (QSTATE)&Pelican::vehiclesEnabled;
}
//............................................................................
QSTATE Pelican::pedestriansEnabled(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            signalVehicles(RED);
            return 0;
        case Q_INIT_SIG:
            Q_INIT(&Pelican::pedestriansWalk);
            return 0;
    }
    return (QSTATE)&Pelican::operational;
}
//............................................................................
QSTATE Pelican::pedestriansWalk(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(hWnd_, IDC_STATE, "pedestriansWalk");
            signalPedestrians(WALK);
            SetTimer(hWnd_, 1, PEDESTRIANS_WALK_TOUT, 0);
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican::pedestriansFlash);
            return 0;
        case Q_EXIT_SIG:
            KillTimer(hWnd_, 1);                      // don't leak the timer!
            return 0;
    }
    return (QSTATE)&Pelican::pedestriansEnabled;
}
//............................................................................
QSTATE Pelican::pedestriansFlash(QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(hWnd_, IDC_STATE, "pedestriansFlash");
            SetTimer(hWnd_, 1, PEDESTRIANS_FLASH_TOUT, 0);
            pedestrianFlashCtr_ = PEDESTRIANS_FLASH_NUM*2 + 1;
            return 0;
        case TIMEOUT_SIG:
            if (pedestrianFlashCtr_ == 0) {                  // done flashing?
                Q_TRAN(&Pelican::vehiclesEnabled);
            }
            else if ((pedestrianFlashCtr_ & 1) == 0) {        // even counter?
                --pedestrianFlashCtr_;
                signalPedestrians(DONT_WALK);
            }
            else {                                      // must be odd counter
                --pedestrianFlashCtr_;
                signalPedestrians(BLANK);
            }
            return 0;
        case Q_EXIT_SIG:
            KillTimer(hWnd_, 1);                      // don't leak the timer!
            return 0;
    }
    return (QSTATE)&Pelican::pedestriansEnabled;
}
//............................................................................
void Pelican::signalVehicles(enum VehiclesSignal sig) {
    ShowWindow(GetDlgItem(hWnd_, IDC_RED),    sig == RED);
    ShowWindow(GetDlgItem(hWnd_, IDC_YELLOW), sig == YELLOW);
    ShowWindow(GetDlgItem(hWnd_, IDC_GREEN),  sig == GREEN);
}
//............................................................................
void Pelican::signalPedestrians(enum PedestriansSignal sig) {
    ShowWindow(GetDlgItem(hWnd_, IDC_DONT_WALK), sig == DONT_WALK);
    ShowWindow(GetDlgItem(hWnd_, IDC_BLANK),     sig == BLANK);
    ShowWindow(GetDlgItem(hWnd_, IDC_WALK),      sig == WALK);
}
//............................................................................
void onAssert__(char const *file, int line) {
    char str[160];
    sprintf(str, "Assertion failed in %s, line %d", file, line);
    MessageBox(mainHwnd, str, appName, MB_ICONEXCLAMATION | MB_OK);
    exit(-1);
}
//............................................................................
BOOL CALLBACK PelicanDlg(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam) {
    QEvent e;
    e.sig = iMsg;
    switch (iMsg) {
        case WM_INITDIALOG: {
            app.hWnd_ = mainHwnd = hwnd;
            app.init(0);                        // take the initial transition
            return TRUE;
        }
        case WM_TIMER: {
            e.sig = TIMEOUT_SIG;
            // intentionally fall thru
        }
        case WM_COMMAND: {
            switch (LOWORD(wParam)) {
            case IDCANCEL:
                e.sig = OFF_SIG;
                break;
            case IDC_PEDESTRIAN_WAITING:
                e.sig = PEDESTRIAN_WAITING_SIG;
                break;
            }
            app.dispatch(&e);                            // dispatch the event
            return TRUE;
        }
    }
    return FALSE;
}
//............................................................................
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst,
                   PSTR cmdLine, int iCmdShow)
{
    InitCommonControls();                      // load common controls library
    inst = hInst;                                     // store instance handle
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, PelicanDlg);
    return 0;                     // exit application when the dialog returns
}

