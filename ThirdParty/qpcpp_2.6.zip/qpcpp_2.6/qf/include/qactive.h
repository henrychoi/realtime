/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef qactive_h
#define qactive_h

#ifndef qhsm_h
    #include "qhsm.h"
#endif

class QActive : public QHsm {              // Quantum Active Object base class
public:
    int start(unsigned prio, QEvent *qSto[], unsigned qLen,
              int stkSto[], unsigned stkLen);
    void postFIFO(QEvent *e);          // post event directly (FIFO enqueuing)
    void postLIFO(QEvent *e);          // post event directly (LIFO enqueuing)
    void run();           // run() is active throughout lifetime of the object
protected:
    QActive(QPseudoState initial);                           // protected ctor
    virtual ~QActive();                                        // virtual xtor
    void stop();             // stopps the thread; nothing happens thereafter!
private:
    int enqueue(QEvent *e);         // intended to use only by friend class QF
private:                                                    // data members...
    QF_EQUEUE(myEqueue)                  // OS-dependent event-queue primitive
        QF_THREAD(myThread)                   // OS-dependent thread primitive
    unsigned char myPrio;                     // priority of the active object
    friend class QF;
};

#endif                                                            // qactive_h
