/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

CRITICAL_SECTION pkgWin32CritSect;

//............................................................................
const char *QF::getVersion() {
    return "QF/Win32 version 2.6; (c) 2002-2004 Quantum Leaps";
}
//............................................................................
void QF::osInit() {
    InitializeCriticalSection(&pkgWin32CritSect);
}
//............................................................................
void QF::osCleanup() {
    DeleteCriticalSection(&pkgWin32CritSect);
}
//............................................................................
void QF::background() {
   ASSERT(0);         // Win32 does not support background processing
}
//............................................................................
void QActive::run() {
    QHsm::init();                                // execute initial transition
    for (;;) {
        register QEvent *e = myEqueue.get();                 // wait for event
        dispatch(e);                                      // process the event
        QF::propagate(e);                  // propagate to the next subscriber
    }
}
//............................................................................
static DWORD WINAPI run(LPVOID a) {
   ((QActive *)a)->run();
   return 0;
}
//............................................................................
int QActive::start(unsigned prio, QEvent *qSto[], unsigned qLen,
                   int stkSto[], unsigned stkLen)
{
    REQUIRE(stkSto == 0);                // Windows allocates stack internally
    if (!myEqueue.init(qSto, qLen)) {
        return 0;                                            // return failure
    }
    myPrio = prio;
    QF::add(this);                      // make QF aware of this active object
    switch (myPrio) {
        case 1:  prio = THREAD_PRIORITY_LOWEST;        break;
        case 2:  prio = THREAD_PRIORITY_IDLE;          break;
        case 3:  prio = THREAD_PRIORITY_BELOW_NORMAL;  break;
        case 4:  prio = THREAD_PRIORITY_NORMAL;        break;
        case 5:  prio = THREAD_PRIORITY_ABOVE_NORMAL;  break;
        case 6:  prio = THREAD_PRIORITY_HIGHEST;       break;
        default: prio = THREAD_PRIORITY_TIME_CRITICAL; break;
    }
    DWORD threadId;
    myThread = CreateThread(NULL,
                            stkLen,
                            ::run,
                            this,
                            0,
                            &threadId);
    if (!myThread) {
      return 0;                                              // return failure
    }
    SetThreadPriority(myThread, prio);
    return !0;                                               // return success
}
//............................................................................
void QActive::stop() {
    QF::remove(this);
    ExitThread(0);
    CloseHandle(myThread);
}
//............................................................................
int QActive::enqueue(QEvent *e) {
    return myEqueue.putFIFO(e);
}
//............................................................................
void QActive::postFIFO(QEvent *e) {
    REQUIRE(e->useNum == 0);                       // event must not be in use
    ALLEGE(myEqueue.putFIFO(e));                      // queue cannot overflow
}
//............................................................................
void QActive::postLIFO(QEvent *e) {
    REQUIRE(e->useNum == 0);                       // event must not be in use
    ALLEGE(myEqueue.putLIFO(e));                      // queue cannot overflow
}
