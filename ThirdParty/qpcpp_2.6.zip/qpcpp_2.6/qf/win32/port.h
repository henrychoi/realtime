/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef port_h
#define port_h

#include "qf_win32.h"
#include "qfpkg.h"

                                 // Win32-specific critical section operations
extern  CRITICAL_SECTION      pkgWin32CritSect;
#define QF_PROTECT()          EnterCriticalSection(&pkgWin32CritSect)
#define QF_UNPROTECT()        LeaveCriticalSection(&pkgWin32CritSect)
#define QF_ISR_PROTECT()      QF_PROTECT()
#define QF_ISR_UNPROTECT()    QF_UNPROTECT()

                                               // Win32-compiler-specific cast
#define Q_STATE_CAST(x_)      reinterpret_cast<QState>(x_)

                                      // Win32-specific event queue operations
#define QF_EQUEUE_INIT(q_) \
    ((q_)->myOsEvent = CreateEvent(NULL, FALSE, FALSE, NULL))
#define QF_EQUEUE_CLEANUP(q_) CloseHandle((q_)->myOsEvent)
#define QF_EQUEUE_WAIT(q_) \
    QF_UNPROTECT(); \
    do { \
        WaitForSingleObject((q_)->myOsEvent, INFINITE); \
    } while ((q_)->myFrontEvt == 0); \
    QF_PROTECT()
#define QF_EQUEUE_SIGNAL(q_) \
    QF_UNPROTECT(); \
    SetEvent((q_)->myOsEvent)
#define QF_EQUEUE_ONEMPTY(q_)

                                       // Win32-specific event pool operations
#define QF_EPOOL              QEPool
#define QF_EPOOL_EVENT_SIZE(p_) ((p_)->myEvtSize)
#define QF_EPOOL_INIT(p_, poolSto_, nEvts_, evtSize_) \
    (p_)->init(poolSto_, nEvts_, evtSize_);
#define QF_EPOOL_GET(p_, e_)  ((e_) = (p_)->get())
#define QF_EPOOL_PUT(p_, e_)  ((p_)->put(e_))

// the following constant may be bumped up to 15 (inclusive)
// before redesign of algorithms is necessary
enum { QF_MAX_ACTIVE = 15 };


#endif                                                               // port_h

