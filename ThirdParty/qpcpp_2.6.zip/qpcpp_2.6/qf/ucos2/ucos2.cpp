/*****************************************************************************
* Product:  QF/C++ 2.6.xx port to uC/OS-II under DOS with Borland C++ 3.1
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

//............................................................................
const char *QF::getVersion() {
    return "Port of QF/C++ 2.6.xx to uC/OS-II";
}
//............................................................................
void QF::osInit() {
}
//............................................................................
void QF::osCleanup() {
}
//............................................................................
void QF::background() {
    ASSERT(0);               // uC/OS-2 does not support background processing
}
//............................................................................
void QActive::run() {
    init();                                      // execute initial transition
    for (;;) {
        INT8U err;
        QEvent *e = (QEvent*)OSQPend((OS_EVENT *)myEqueue, 0, &err);
        dispatch(e);                         // dispatch evt to the statechart
        QF::propagate(e);                  // propagate to the next subscriber
    }
}
//............................................................................
extern "C" void run(void *a) {
    ((QActive *)a)->run();
}
//............................................................................
int QActive::start(unsigned prio, QEvent *qSto[], unsigned qLen,
                   int stkSto[], unsigned stkLen)
{
    myPrio = prio;
    QF::add(this);                      // make QF aware of this active object
    myEqueue = OSQCreate((void **)qSto, qLen);
    if (myEqueue == 0) {
        return 0;        // failed to create MicroC/OS mailbox -- return error
    }
    myThread = QF_MAX_ACTIVE - myPrio;             // map QF priority to uC/OS
    if ((OSTaskCreate(::run,
        this,
        (OS_STK *)(stkSto + stkLen - 1),                       // top of stack
        myThread)) != OS_NO_ERR) {
        return 0;         // failed to create MicroC/OS thread -- return error
    }
    return !0;                                               // return success
}
//............................................................................
void QActive::stop() {
    QF::remove(this);
    //OSTaskDel(myThread);
}
//............................................................................
int QActive::enqueue(QEvent *e) {
    return OSQPost((OS_EVENT *)myEqueue, (void *)e) == OS_NO_ERR;
}
//............................................................................
void QActive::postFIFO(QEvent *e) {
    REQUIRE(e->useNum == 0);                       // event must not be in use
    ALLEGE(OSQPost((OS_EVENT *)myEqueue, (void *)e) == OS_NO_ERR);
}
//............................................................................
void QActive::postLIFO(QEvent *e) {
    REQUIRE(e->useNum == 0);                       // event must not be in use
    ALLEGE(OSQPostFront((OS_EVENT *)myEqueue, (void*)e) == OS_NO_ERR);
}
