/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

//............................................................................
void QEPool::init(QEvent *poolSto, unsigned nEvts, unsigned evtSize){
    REQUIRE(nEvts > 0 && evtSize >= sizeof(QEvent));
    myFree =  poolSto;               // set head of linked-list of free events
    myEvtSize = evtSize;                   // store maximum size of each event
    myNtot = nEvts;                            // store total number of events
    myNfree = nEvts;                            // store number of free events
    myNmin = nEvts;            // initialize the minimum number of free events
    register char *block = (char *)poolSto;
    while (--nEvts != 0) {             // chain all blocks in the free-list...
        *(void **)block = (void *)(block + evtSize);           // set the link
        block += evtSize;                             // advance to next block
    }
    *(void **)block = 0;                              // last link points to 0
}
//............................................................................
QEvent *QEPool::get() {
    register QEvent *e;
    QF_PROTECT();
    if (myNfree > 0) {                               // free events available?
        e = (QEvent *)myFree;                                // get free event
        myFree = *(void **)e;               // adjust pointer to new free list
        if (--myNfree < myNmin) {               // one less event in this pool
            myNmin = myNfree;                   // remember the minimum so far
        }
    }
    else {
        e = 0;
    }
    QF_UNPROTECT();
    return e;                    // return event or NULL pointer to the caller
}
//............................................................................
void QEPool::put(QEvent *e) {
    QF_PROTECT();
    REQUIRE(myNfree < myNtot);             // # of free events must be < total
    *(void **)e = myFree;              // insert released event into free list
    myFree = e;                            // set as new head of the free list
    ++myNfree;                                  // one more event in this pool
    QF_UNPROTECT();
}
