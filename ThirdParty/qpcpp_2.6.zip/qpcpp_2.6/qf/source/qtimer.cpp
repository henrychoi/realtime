/*****************************************************************************
* Product:  QF/C++
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 20 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

//............................................................................
QTimer *pkgTimerListHead;                     // head of linked list of timers

//............................................................................
void QTimer::arm(QActive *act, QSignal sig, unsigned nTicks) {
    REQUIRE(nTicks != 0                  /* cannot arm a timer with 0 ticks */
            && myActive == 0);               // the timer must *not* be in use
    myActive = act;
    myToutEvt.sig = sig;
    myToutEvt.poolId = 0;                                  // not a pool event
    myToutEvt.useNum = 0;                                    // event not used
    myCtr = nTicks;
    QF_PROTECT();
    myNext = pkgTimerListHead;
    pkgTimerListHead = this;
    QF_UNPROTECT();
}
//............................................................................
// setup a periodic timer to fire EVERY 'nTicks' clock ticks and send
// timeout event 'toutSig' to active object 'act'
void QTimer::fireEvery(QActive *act, QSignal sig, unsigned nTicks) {
    myInterval = nTicks;
    arm(act, sig, nTicks);
}
//............................................................................
// setup a one-shot timer to fire IN 'nTicks' clock ticks and send
// timeout event 'toutSig' to active object 'act'
void QTimer::fireIn(QActive *act, QSignal sig, unsigned nTicks) {
    myInterval = 0;
    arm(act, sig, nTicks);
}
//............................................................................
// rearm a timer to fire in/every nTicks (if 'nTicks'==0 the old
// value is restored)
void QTimer::rearm(unsigned nTicks) {
    REQUIRE(nTicks > 0);
    QF_PROTECT();
    myCtr = nTicks;
    QF_UNPROTECT();
}
//............................................................................
void QTimer::disarm() {
    REQUIRE(myActive != 0);                      // the timer *must* be in use
    QF_PROTECT();
    myCtr = 1;                                        // arm for only one tick
    myInterval = 0;                                // make it a one-shot timer
    myToutEvt.sig = Q_EMPTY_SIG;          // generate Q_EMPTY_SIG upon timeout
    QF_UNPROTECT();
}

