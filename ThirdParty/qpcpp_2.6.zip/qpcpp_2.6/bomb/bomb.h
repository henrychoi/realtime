//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bomb.rc
//
#define IDS_APP_TITLE                   1
#define IDD_DIALOG                      101
#define IDI_QL                          103
#define IDB_RED                         105
#define IDB_YELLOW                      106
#define IDB_BLAST                       107
#define IDB_GREY                        108
#define IDC_ARM                         1011
#define IDC_DOWN                        1012
#define IDC_UP                          1013
#define IDC_RED                         1017
#define IDC_YELLOW                      1018
#define IDC_BLAST                       1024
#define IDC_GREY                        1025
#define IDC_STATE                       1100
#define IDC_TIMEOUT                     1101

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
