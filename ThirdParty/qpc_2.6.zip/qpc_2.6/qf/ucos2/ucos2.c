/*****************************************************************************
* Product:  QF/C 2.6.xx port to uC/OS-II under DOS with Borland C++ 3.1
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

/*..........................................................................*/
const char *QFgetVersion() {
    return "Port of QF/C 2.6.xx to uC/OS-II";
}
/*..........................................................................*/
void QFosInit__() {
}
/*..........................................................................*/
void QFosCleanup__() {
}
/*..........................................................................*/
void QFbackground() {
    ASSERT(0);           /* uC/OS-II does not support background processing */
}
/*..........................................................................*/
void QActiveRun(QActive *me) {
    QHsmInit((QHsm *)me, 0);                  /* execute initial transition */
    for (;;) {
        INT8U err;
        QEvent *e = (QEvent*)OSQPend((OS_EVENT*)me->eQueue__, 0, &err);
        QHsmDispatch((QHsm *)me, e);             /* dispatch evt to the HSM */
        QFpropagate__(e);               /* propagate to the next subscriber */
    }
}
/*..........................................................................*/
int QActiveStart(QActive *me, unsigned prio,
                 QEvent *qSto[], unsigned qLen,
                 int stkSto[], unsigned stkLen)
{
    me->prio__ = prio;
    QFadd__(me);                     /* make QF aware of this active object */
    me->eQueue__ = OSQCreate((void **)qSto, qLen);
    if (me->eQueue__ == 0) {
        return 0;          /* failed to create uC/OS message queue -- error */
    }
    me->thread__ = QF_MAX_ACTIVE - prio;        /* map QF priority to uC/OS */
    if ((OSTaskCreate((void (*)(void *))QActiveRun,
        me,
        (OS_STK *)(stkSto + stkLen - 1),                    /* top of stack */
        me->thread__)) != OS_NO_ERR)
    {
        return 0;       /*failed to create MicroC/OS thread -- return error */
    }
    return !0;                                            /* return success */
}
/*..........................................................................*/
void QActiveStop(QActive *me) {
    QFremove__(me);
    /*OSTaskDel(me->thread__);*/
}
/*..........................................................................*/
int QActiveEnqueue__(QActive *me, QEvent *e) {
    return OSQPost((OS_EVENT *)me->eQueue__, (void *)e) == OS_NO_ERR;
}
/*..........................................................................*/
void QActivePostFIFO(QActive *me, QEvent *e) {
    REQUIRE(e->useNum == 0);                    /* event must not be in use */
    ALLEGE(OSQPost((OS_EVENT *)me->eQueue__, (void *)e) == OS_NO_ERR);
}
/*..........................................................................*/
void QActivePostLIFO(QActive *me, QEvent *e) {
    REQUIRE(e->useNum == 0);                    /* event must not be in use */
    ALLEGE(OSQPostFront((OS_EVENT *)me->eQueue__, (void*)e) == OS_NO_ERR);
}
