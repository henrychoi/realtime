/*****************************************************************************
* Product:  QF/C 2.6.xx port to uC/OS-II under DOS with Borland C++ 3.1
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef port_h
#define port_h

#include "qf_ucos2.h"
#include "qfpkg.h"

/* minimal uC/OS-II configuration required to include appropriate elements
 * from the following "ucos_ii.h" header file
 */
#define OS_MAX_EVENTS   2
#define OS_MAX_MEM_PART 2
#define OS_MAX_QS       2
#define OS_MEM_EN       1
#define OS_Q_EN         1
#define OS_LOWEST_PRIO  15
#include "os_cpu.h"
#include "ucos_ii.h"                               /* uC/OS-II include file */

                           /* uC/OS-II-specific critical section operations */
#define QF_PROTECT()        OS_ENTER_CRITICAL()
#define QF_UNPROTECT()      OS_EXIT_CRITICAL()
#define QF_ISR_PROTECT()
#define QF_ISR_UNPROTECT()

                                         /* uC/OS-II-compiler-specific cast */
#define Q_STATE_CAST(x_)    (QState)(x_)

                                 /* uC/OS-II-specific event pool operations */
#define QF_EPOOL            OS_MEM
#define QF_EPOOL_EVENT_SIZE(p_) ((p_)->OSMemBlkSize)
#define QF_EPOOL_INIT(p_, poolSto_, nEvts_, evtSize_) \
    do { \
        INT8U err; \
        (p_) = OSMemCreate(poolSto_, nEvts_, evtSize_, &err);\
        ASSERT((p_) != 0);\
    } while (0)
#define QF_EPOOL_GET(p_, e_) \
    do { \
        INT8U err; \
        ((e_) = (QEvent *)OSMemGet((p_), &err)); \
    } while (0)
#define QF_EPOOL_PUT(p_, e_) OSMemPut((p_), (void *)(e_));

/* the following constant may be bumped up to 15 (inclusive)
 * before redesign of algorithms is necessary */
enum { QF_MAX_ACTIVE = OS_LOWEST_PRIO };

#endif                                                            /* port_h */
