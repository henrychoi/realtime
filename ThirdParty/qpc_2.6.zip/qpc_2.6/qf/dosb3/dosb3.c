/*****************************************************************************
* Product:  QF/C 2.6.xx port to DOS with Borland Turbo C++ 1.01
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

unsigned char pkgRdyMask;

/*..........................................................................*/
const char *QFgetVersion() {
    return "QF/C 2.6 port to DOS with Borland C++ 3.1";
}
/*..........................................................................*/
void QFosInit__() {
}
/*..........................................................................*/
void QFosCleanup__() {
}
/*..........................................................................*/
void QFbackground() {
    static const unsigned char lbLkup[] = {
        0, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4,
        5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8
   };

    while (pkgRdyMask) {
        QActive *a = pkgActive[lbLkup[pkgRdyMask]];
        register QEvent *evt = (QEvent *)QEQueueGet(&a->eQueue__);
        QHsmDispatch((QHsm *)a, evt);            /* dispatch evt to the HSM */
        QFpropagate__(evt);             /* propagate to the next subscriber */
    }
}
/*..........................................................................*/
int QActiveStart(QActive *me, unsigned prio,
    QEvent **qSto, unsigned qLen,
    int *stkSto, unsigned stkLen)
{
    REQUIRE(0 < prio && prio <= QF_MAX_ACTIVE
            && stkSto == 0);           /* DOS does not need per-actor stack */
    me->prio__ = prio;
    QFadd__(me);                     /* make QF aware of this active object */
    if (!QEQueueCtor(&me->eQueue__, qSto, qLen)) {
        return 0;                                         /* return failure */
    }
    me->eQueue__.osEvent__ = 1 << (prio - 1);       /* bit-mask 4 the actor */
    QHsmInit((QHsm *)me, 0);                  /* execute initial transition */
    return !0;                                            /* return success */
}
/*..........................................................................*/
void QActiveStop(QActive *me) {
    QFremove__(me);
}
/*..........................................................................*/
int QActiveEnqueue__(QActive *me, QEvent *evt) {
    return QEQueuePutFIFO(&me->eQueue__, evt);
}
/*..........................................................................*/
void QActivePostFIFO(QActive *me, QEvent *evt) {
    REQUIRE(evt->useNum == 0);                  /* event must not be in use */
    ALLEGE(QEQueuePutFIFO(&me->eQueue__, evt));         /* cannot overflow! */
}
/*..........................................................................*/
void QActivePostLIFO(QActive *me, QEvent *evt) {
    REQUIRE(evt->useNum == 0);                  /* event must not be in use */
    ALLEGE(QEQueuePutLIFO(&me->eQueue__, evt));         /* cannot overflow! */
}
