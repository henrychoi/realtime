/*****************************************************************************
* Product:  QF/C 2.6.xx port to DOS with Borland C++ 1.01
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 21 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef port_h
#define port_h

#include "qf_dosb3.h"
#include "qfpkg.h"

                                /* DOS-specific critical section operations */
#define QF_PROTECT()          _disable()
#define QF_UNPROTECT()        _enable()
#define QF_ISR_PROTECT()
#define QF_ISR_UNPROTECT()

                                     /* DOS-specific event queue operations */
#define QF_EQUEUE_INIT(q_)    (1)
#define QF_EQUEUE_CLEANUP(q_)
#define QF_EQUEUE_WAIT(q_)    ASSERT(0)
#define QF_EQUEUE_SIGNAL(q_) \
    pkgRdyMask |= (q_)->osEvent__; \
    QF_UNPROTECT()
#define QF_EQUEUE_ONEMPTY(q_) \
    if ((q_)->nUsed__ == 0) { \
        pkgRdyMask &= ~(q_)->osEvent__; \
    } else ((void)0)

                                      /* DOS-specific event pool operations */
#define QF_EPOOL              QEPool
#define QF_EPOOL_EVENT_SIZE(p_) ((p_)->evtSize__)
#define QF_EPOOL_INIT(p_, poolSto_, nEvts_, evtSize_) \
    QEPoolCtor(p_, poolSto_, nEvts_, evtSize_);
#define QF_EPOOL_GET(p_, e_)  ((e_) = (QEvent *)QEPoolGet(p_))
#define QF_EPOOL_PUT(p_, e_)  (QEPoolPut(p_, e_))

/* the following constant may be bumped up to 15 (inclusive)
 * before redesign of algorithms is necessary
 */
enum { QF_MAX_ACTIVE = 8 };

/* package-scope variables */
extern unsigned char pkgRdyMask;

#endif                                                            /* port_h */

