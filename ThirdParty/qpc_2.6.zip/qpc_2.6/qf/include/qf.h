/*****************************************************************************
* Product:  QF/C
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef qf_h
#define qf_h

/* densly packet 32-bit "list" of subscriber active objects,
 * allocating 4-bits per active object-id allows to store
 * up to 8 subscribers in this "list"
 */
typedef unsigned long QSubscrList;

                                                                /* class QF */
/* public methods */
void QFinit(QSubscrList subscr[], unsigned maxSignal);
void QFcleanup();
void QFpoolInit(QEvent *poolSto, unsigned nEvts, unsigned evtSize);
void QFtick();
char const *QFgetVersion();
QEvent *QFcreate(unsigned evtSize, QSignal sig);
#define Q_NEW(evtT_, sig_) ((evtT_ *)QFcreate(sizeof(evtT_), (sig_)))
void QFsubscribe(QActive *a, QSignal sig);
void QFunsubscribe(QActive *a, QSignal sig);
void QFpublish(QEvent *e);                                 /* publish event */

void QFbackground();              /* for foreground/background systems only */

                   /* private methods (internal interface for QActive only) */
void QFosInit__();
void QFosCleanup__();
void QFadd__(QActive *a);
void QFremove__(QActive *a);
void QFpropagate__(QEvent *e);              /* propagate to next subsrciber */
void QFannihilate__(QEvent *e);

#endif                                                              /* qf_h */
