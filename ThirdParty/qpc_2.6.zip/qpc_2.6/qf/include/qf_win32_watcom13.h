/*****************************************************************************
* Product:  QF/C 2.6.xx port to Win32 with Open Watcom C++ 1.3
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef qf_win32_watcom13_h
#define qf_win32_watcom13_h

#include <windows.h>

                       /* Win32-specific event pool, queue and thread types */
#define QF_OS_EVENT(x_)  HANDLE  x_;
#define QF_EQUEUE(x_)    QEQueue x_;
#define QF_THREAD(x_)    HANDLE  x_;

#include "qevent.h"
#include "qfsm.h"
#include "qhsm.h"
#include "qequeue.h"                             /* Win32 needs event-queue */
#include "qepool.h"                               /* Win32 needs event-pool */
#include "qactive.h"
#include "qtimer.h"
#include "qf.h"

#endif                                               /* qf_win32_watcom13_h */
