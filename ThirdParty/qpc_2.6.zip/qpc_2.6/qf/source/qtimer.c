/*****************************************************************************
* Product:  QF/C
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

/*..........................................................................*/
QTimer *pkgTimerListHead;                  /* head of linked list of timers */

/*..........................................................................*/
static void QTimerAdd(QTimer *me, QActive *act,
                      QSignal toutSig, unsigned nTicks)
{
    QF_PROTECT();
    REQUIRE(me->active__ == 0);           /* the timer must *not* be in use */
    me->active__ = act;
    me->toutEvt__.sig = toutSig;
    me->toutEvt__.poolId = 0;                           /* not a pool event */
    me->toutEvt__.useNum = 0;                             /* event not used */
    me->ctr__ = nTicks;
    me->next__ = pkgTimerListHead;
    pkgTimerListHead = me;
    QF_UNPROTECT();
}
/*............................................................................
 * setup a periodic timer to fire EVERY 'nTicks' clock ticks and send
 * timeout message 'toutSig' to active object 'act'
 */
void QTimerFireEvery(QTimer *me, QActive *act,
                     QSignal toutSig, unsigned nTicks)
{
    me->interval__ = nTicks;
    QTimerAdd(me, act, toutSig, nTicks);
}
/*............................................................................
 * setup a one-shot timer to fire IN 'nTicks' clock ticks and send
 * timeout message 'toutSig' to active object 'act'
 */
void QTimerFireIn(QTimer *me, QActive *act,
                  QSignal toutSig, unsigned nTicks)
{
    me->interval__ = 0;
    QTimerAdd(me, act, toutSig, nTicks);
}
/*............................................................................
 * rearm a timer to fire in/every nTicks (if 'nTicks'==0 the old
 * value is restored)
 */
void QTimerRearm(QTimer *me, unsigned nTicks) {
    QF_PROTECT();
    me->ctr__ = nTicks;
    QF_UNPROTECT();
}
/*............................................................................
 * disarm currently armed timer
 */
void QTimerDisarm(QTimer *me) {
    REQUIRE(me->active__ != 0);               /* the timer *must* be in use */
    QF_PROTECT();
    me->ctr__ = 1;                                 /* arm for only one tick */
    me->interval__ = 0;                         /* make it a one-shot timer */
    me->toutEvt__.sig = Q_EMPTY_SIG;            /* Q_EMPTY_SIG upon timeout */
    QF_UNPROTECT();
}

