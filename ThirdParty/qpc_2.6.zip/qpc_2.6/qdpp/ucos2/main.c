/*****************************************************************************
* Product:  QF/C 2.6.xx port to uC/OS-II under DOS with Borland C++ 3.1
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include "qassert.h"
#include "port.h"
#include "includes.h"                       /* master uC/OS-II include file */
//#include "pc.h"

DEFINE_THIS_FILE;

/*..........................................................................*/
enum {                               /* we need to add some more signals... */
    KBD_SIG = MAX_SIG,
    MMAX_SIG
};

/*--------------------------------------------------------------------------*/
typedef struct KbdEvt KbdEvt;
struct KbdEvt {
    QEvent super_;
    unsigned char key;
};

/*--------------------------------------------------------------------------*/
typedef struct KbdMgr KbdMgr;
struct KbdMgr {                                         /* keyboard manager */
    QActive super_;                                      /* extends QActive */
};

KbdMgr *KbdMgrCtor(KbdMgr *me);

                                                    /* protected methods... */
void KbdMgr_initial(KbdMgr *me, QEvent const *e);
QSTATE KbdMgr_active(KbdMgr *me, QEvent const *e);

/*..........................................................................*/
KbdMgr *KbdMgrCtor(KbdMgr *me) {
    QActiveCtor_(&me->super_, (QPseudoState)KbdMgr_initial);
    return me;
}
/*..........................................................................*/
void KbdMgr_initial(KbdMgr *me, QEvent const *e) {
    QFsubscribe((QActive *)me, KBD_SIG);
    Q_INIT(&KbdMgr_active);
}
/*..........................................................................*/
QSTATE KbdMgr_active(KbdMgr *me, QEvent const *e) {
    switch (e->sig) {
    case KBD_SIG:
        if (((KbdEvt const *)e)->key == '\033') {               /* ESC key? */
            PC_DOSReturn();                                /* Return to DOS */
        }
        return 0;
    }
    return (QSTATE)&QHsm_top;
}
/*..........................................................................*/
static Table aTable;
static Philosopher aPhil[N];
static KbdMgr aKbdMgr;
static QEvent *tableQueueSto[N];
static QEvent *philQueueSto[N][N];
static QEvent *kbdMgrQueueSto[1];
static QSubscrList subscrSto[MMAX_SIG];
static TableEvt regPoolSto[N*N];

static int TableStk[256];              /* stack for the Table active object */
static int PhilosopherStk[N][256];           /* stacks for the philosophers */
static int kbdMgrStk[256];                /* stack for the keyboard menager */

/*..........................................................................*/
void onAssert__(char const *file, int line) {
    fprintf(stderr, "Assertion failed in %s, line %d", file, line);
    PC_DOSReturn();                                        /* Return to DOS */
}
/*..........................................................................*/
void OSTimeTickHook(void) {
    int key;
    QFtick();
    if (PC_GetKey(&key)) {                   /* See if key has been pressed */
        KbdEvt *pe = Q_NEW(KbdEvt, KBD_SIG);
        pe->key = (unsigned char)key;
        QFpublish((QEvent *)pe);
    }
}
/*..........................................................................*/
void OSTaskCreateHook (OS_TCB *tcb) {
}
/*..........................................................................*/
void OSTaskDelHook (OS_TCB *tcb) {
}
/*..........................................................................*/
void OSTaskSwHook (void) {
}
/*..........................................................................*/
void OSTaskStatHook (void) {
}
/*..........................................................................*/
main() {
    unsigned n;
    OSInit();                                        /* initialize uC/OS-II */
    PC_DOSSaveReturn();                /* Save environment to return to DOS */
    PC_VectSet(uCOS, OSCtxSw);             /* install context switch vector */
    OS_ENTER_CRITICAL();
    PC_VectSet(0x08, OSTickISR);       /* Install uC/OS-II's clock tick ISR */
    PC_SetTickRate(OS_TICKS_PER_SEC);                /* Reprogram tick rate */
    OS_EXIT_CRITICAL();
    printf("Quantum DPP, built on %s at %s, libraries: %s\n",
        __DATE__, __TIME__, QFgetVersion());
    QFinit(subscrSto, DIM(subscrSto));
    QFpoolInit((QEvent *)regPoolSto,
        DIM(regPoolSto), sizeof(TableEvt));

    for (n = 0; n < N; ++n) {
        PhilosopherCtor(&aPhil[n], n);
        QActiveStart((QActive *)&aPhil[n], n + 1,
            philQueueSto[n], DIM(philQueueSto[n]),
            PhilosopherStk[n], DIM(PhilosopherStk[n]));
    }
    TableCtor(&aTable);
    QActiveStart((QActive *)&aTable, N + 1,
        tableQueueSto, DIM(tableQueueSto),
        TableStk, DIM(TableStk));
    KbdMgrCtor(&aKbdMgr);
    QActiveStart((QActive *)&aKbdMgr, N + 2,
        kbdMgrQueueSto, DIM(kbdMgrQueueSto),
        kbdMgrStk, DIM(kbdMgrStk));

    OSStart();                                        /* Start multitasking */
    return 0;/* OSStart never returns, this is to suppress compiler warning */
}
