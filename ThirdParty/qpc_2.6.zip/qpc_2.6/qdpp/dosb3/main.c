/*****************************************************************************
* Product:  QF/C 2.6.xx port to DOS with Borland C++ 3.1
* Version:  1.0
* Released: Dec 27 2003
* Updated:  Dec 21 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

/*..........................................................................*/
enum { TICK_VECTOR = 0x08 };

static void interrupt (*dosISR)() ;
static QSubscrList subscrSto[MAX_SIG];
static TableEvt regPoolSto[20];
static Table aTable;
static Philosopher aPhil[N];
static QEvent *tableQueueSto[10];
static QEvent *philQueueSto[N][10];

/*..........................................................................*/
void onAssert__(char const *file, int line) {
    fprintf(stderr, "Assertion failed in %s, line %d", file, line);
    exit(-1);
}
/*..........................................................................*/
void interrupt ISR() {
    QFtick();
    (*dosISR)();           /* chain to the stanard DOS time-tick processing */
}
/*..........................................................................*/
int main() {
    unsigned n;

    printf("Quantum DPP, built on %s at %s, libraries: %s\n",
            __DATE__, __TIME__, QFgetVersion());

    QFinit(subscrSto, MAX_SIG);
    QFpoolInit((QEvent *)regPoolSto, DIM(regPoolSto), sizeof(TableEvt));

                                     /* construct and start active objects  */
    for (n = 0; n < N; ++n) {
        PhilosopherCtor(&aPhil[n], n);
        QActiveStart((QActive *)&aPhil[n], n + 1,
                     philQueueSto[n], DIM(philQueueSto[n]), 0, 0);
    }
    TableCtor(&aTable);
    QActiveStart((QActive *)&aTable, N + 1,
                 tableQueueSto, DIM(tableQueueSto), 0, 0);

    dosISR = _dos_getvect(TICK_VECTOR);
    _disable();
    _dos_setvect(TICK_VECTOR, ISR);
    _enable();

    for (;;) {                                        /* the bacground loop */
        QFbackground();
        if (kbhit()) {
            break;
        }
    }

    QFcleanup();

    _disable();
    _dos_setvect(TICK_VECTOR, dosISR);
    _enable();
    return 0;
}
