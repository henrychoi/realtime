/*****************************************************************************
* Product:  QF/C
* Version:  2.6
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include "qassert.h"
#include "port.h"

DEFINE_THIS_FILE;

enum { THINK_TIME = 7, EAT_TIME = 5 };

/*..........................................................................*/
Philosopher *PhilosopherCtor(Philosopher *me, int n) {
    QActiveCtor_(&me->super_, (QPseudoState)&Philosopher_initial);
    me->num__ = n;
    return me;
}
/*..........................................................................*/
void Philosopher_initial(Philosopher *me, QEvent const *e) {
    printf("Initializing philospher %1d\n", me->num__);
    QFsubscribe((QActive *)me, EAT_SIG);
    Q_INIT(&Philosopher_thinking);
}
/*..........................................................................*/
QSTATE Philosopher_thinking(Philosopher *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            QTimerFireIn(&me->timer__, (QActive *)me, TIMEOUT_SIG,
                         THINK_TIME);
            return 0;
        }
        case TIMEOUT_SIG: {
            Q_TRAN(&Philosopher_hungry);
            return 0;
        }
    }
    return (QSTATE)&QHsm_top;
}
/*..........................................................................*/
QSTATE Philosopher_hungry(Philosopher *me, QEvent const *e) {
    TableEvt *pe;
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            pe = Q_NEW(TableEvt, HUNGRY_SIG);
            pe->philNum = me->num__;
            QFpublish((QEvent *)pe);
            return 0;
        }
        case EAT_SIG: {
            if (((TableEvt *)e)->philNum == me->num__) {
                Q_TRAN(&Philosopher_eating);
            }
            return 0;
        }
    }
    return (QSTATE)&QHsm_top;
}
/*..........................................................................*/
QSTATE Philosopher_eating(Philosopher *me, QEvent const *e) {
    TableEvt *pe;
    switch (e->sig) {
        case Q_ENTRY_SIG: {
            QTimerFireIn(&me->timer__, (QActive *)me, TIMEOUT_SIG,
                         EAT_TIME);
            return 0;
        }
        case TIMEOUT_SIG: {
            pe = Q_NEW(TableEvt, DONE_SIG);
            pe->philNum = me->num__;
            QFpublish((QEvent *)pe);
            Q_TRAN(Philosopher_thinking);
            return 0;
        }
    }
    return (QSTATE)&QHsm_top;
}
/*..........................................................................*/
#define RIGHT(i) (((i) + (N - 1)) % N)
#define LEFT(i)  (((i) + 1) % N)
enum {
    FREE = 0, USED = !0
};
/*..........................................................................*/
Table *TableCtor(Table *me) {
    QActiveCtor_(&me->super_, (QPseudoState)&Table_initial);
    return me;
}
/*..........................................................................*/
void Table_initial(Table *me, QEvent const *e) {
    unsigned n;
    QFsubscribe((QActive *)me, HUNGRY_SIG);
    QFsubscribe((QActive *)me, DONE_SIG);
    for (n = 0; n < N; ++n) {
        me->fork__[n] = FREE;
        me->isHungry__[n] = 0;
    }
    Q_INIT(&Table_serving);
}
/*..........................................................................*/
QSTATE Table_serving(Table *me, QEvent const *e) {
    unsigned n, m;
    TableEvt *pe;
    switch (e->sig) {
        case HUNGRY_SIG: {
            n = ((TableEvt *)e)->philNum;
            ASSERT(n < N && !me->isHungry__[n]);
            printf("Philospher %1d is hungry\n", n);
            m = LEFT(n);
            if (me->fork__[m] == FREE && me->fork__[n] == FREE) {
                me->fork__[m] = me->fork__[n] = USED;
                pe = Q_NEW(TableEvt, EAT_SIG);
                pe->philNum = n;
                QFpublish((QEvent *)pe);
                printf("Philospher %1d is eating\n", n);
            }
            else {
                me->isHungry__[n] = 1;
            }
            return 0;
        }
        case DONE_SIG: {
            n = ((TableEvt *)e)->philNum;
            ASSERT(n < N);
            printf("Philospher %1d is thinking\n", n);
            me->fork__[LEFT(n)] = me->fork__[n] = FREE;
            m = RIGHT(n);
            if (me->isHungry__[m] && me->fork__[m] == FREE) {
                me->fork__[n] = me->fork__[m] = USED;
                me->isHungry__[m] = 0;
                pe = Q_NEW(TableEvt, EAT_SIG);
                pe->philNum = m;
                QFpublish((QEvent *)pe);
                printf("Philospher %1d is eating\n", m);
            }
            m = LEFT(n);
            n = LEFT(m);
            if (me->isHungry__[m] && me->fork__[n] == FREE) {
                me->fork__[m] = me->fork__[n] = USED;
                me->isHungry__[m] = 0;
                pe = Q_NEW(TableEvt, EAT_SIG);
                pe->philNum = m;
                QFpublish((QEvent *)pe);
                printf("Philospher %1d is eating\n", m);
            }
            return 0;
        }
    }
    return (QSTATE)&QHsm_top;
}
