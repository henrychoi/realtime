/*****************************************************************************
* Product:  QF/C
* Version:  2.5
* Released: Dec 27 2003
* Updated:  Dec 12 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef qdpp_h
#define qdpp_h

enum DPPSignals {
    HUNGRY_SIG = Q_USER_SIG,        /* sent when philosopher becomes hungry */
    DONE_SIG,                       /* sent by philosopher when done eating */
    EAT_SIG,                      /* sent by Table to let a philosopher eat */
    TIMEOUT_SIG,      /* timeout philosophers use to end thinking or eating */
    MAX_SIG
};

SUBCLASS(TableEvt, QEvent)
   int philNum;                                       /* philosopher number */
METHODS
END_CLASS

SUBCLASS(Philosopher, QActive)
    int num__;                                /* number of this philosopher */
    QTimer timer__;                         /* to timeout thining or eating */
METHODS
    Philosopher *PhilosopherCtor(Philosopher *me, int n);
    void Philosopher_initial(Philosopher *me, QEvent const *e);
    QSTATE Philosopher_thinking(Philosopher *me, QEvent const *e);
    QSTATE Philosopher_hungry(Philosopher *me, QEvent const *e);
    QSTATE Philosopher_eating(Philosopher *me, QEvent const *e);
END_CLASS

enum { N = 5 };

SUBCLASS(Table, QActive)
    int fork__[N];
    int isHungry__[N];
METHODS
    Table *TableCtor(Table *me);
    void Table_initial(Table *me, QEvent const *e);
    QSTATE Table_serving(Table *me, QEvent const *e);
END_CLASS

#endif                                                            /* qdpp_h */
