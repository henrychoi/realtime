/*****************************************************************************
* Product:  Quantum Calculator Example
* Version:  Compatible with QEP/C 2.6.xx
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#ifndef calc_h
#define calc_h

#include <windows.h>
#include "qhsm.h"                 /* Hierarchical State Machine part of QEP */

SUBCLASS(CalcEvt, QEvent)
    int keyId;                                   /* ID of the key depressed */
METHODS
END_CLASS

SUBCLASS(Calc, QHsm)
    HWND hWnd_;                             /* the calculator window handle */
    char display_[40];
    char *ins_;
    double operand1_;
    double operand2_;
    int operator_;
METHODS
    Calc *CalcCtor(Calc *me);
    void CalcXtor(Calc *me);
    void Calc_initial(Calc *me, QEvent const *e);
    QSTATE Calc_calc(Calc *me, QEvent const *e);
    QSTATE Calc_ready(Calc *me, QEvent const *e);
    QSTATE Calc_result(Calc *me, QEvent const *e);
    QSTATE Calc_begin(Calc *me, QEvent const *e);
    QSTATE Calc_negated1(Calc *me, QEvent const *e);
    QSTATE Calc_operand1(Calc *me, QEvent const *e);
    QSTATE Calc_zero1(Calc *me, QEvent const *e);
    QSTATE Calc_int1(Calc *me, QEvent const *e);
    QSTATE Calc_frac1(Calc *me, QEvent const *e);
    QSTATE Calc_opEntered(Calc *me, QEvent const *e);
    QSTATE Calc_negated2(Calc *me, QEvent const *e);
    QSTATE Calc_operand2(Calc *me, QEvent const *e);
    QSTATE Calc_zero2(Calc *me, QEvent const *e);
    QSTATE Calc_int2(Calc *me, QEvent const *e);
    QSTATE Calc_frac2(Calc *me, QEvent const *e);

    void CalcClear_(Calc *me);
    void CalcInsert_(Calc *me, int keyId);
    void CalcNegate_(Calc *me);
    void CalcEval_(Calc *me);
    void CalcDispState(Calc *me, char const *s);
END_CLASS

#endif                                                            /* calc_h */
