/*****************************************************************************
* Product:  Simple Time Bomb Example
* Version:  Compatible with QEP/C 2.6.xx
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>

#include "qassert.h"
#include "qfsm.h"                       /* Finite State Machine part of QEP */
#include "bomb.h"                                         /* Bomb resources */

DEFINE_THIS_FILE;

/* Bomb class --------------------------------------------------------------*/
typedef struct Bomb Bomb;
struct Bomb {
    QFsm super_;
    int timeout__;
    int code__;                            /* the current defuse code entry */
};

Bomb *BombCtor(Bomb *me);
void Bomb_setting(Bomb *me, QEvent const *e);
void Bomb_timing(Bomb *me, QEvent const *e);
void Bomb_blast(Bomb *me, QEvent const *e);

/*--------------------------------------------------------------------------*/
enum BombSignals {
    ARM_SIG = Q_USER_SIG,
    TICK_SIG,
    UP_SIG,
    DOWN_SIG
};

enum {
    INIT_TIMEOUT = 5,
    MAX_TIMEOUT = 10,
    DEFUSE_CODE = 0x0D          /* pre-programmed defuse code (1101 binary) */
};

/*--------------------------------------------------------------------------*/
static Bomb locApp;
static HINSTANCE locInst;                               /* this locInstance */
static HWND locHwnd;                                     /* the main window */
static char const locAppName[] = "Bomb";

/*..........................................................................*/
Bomb *BombCtor(Bomb *me) {
    QFsmCtor_(&me->super_, (QFsmState)&Bomb_setting);
    me->timeout__ = INIT_TIMEOUT;
    return me;
}
/*..........................................................................*/
void Bomb_setting(Bomb *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(locHwnd, IDC_STATE, "setting");
            SetDlgItemInt(locHwnd, IDC_TIMEOUT, me->timeout__, FALSE);
            ShowWindow(GetDlgItem(locHwnd, IDC_GREY), TRUE);
            break;
        case Q_EXIT_SIG:
            ShowWindow(GetDlgItem(locHwnd, IDC_GREY), FALSE);
            break;
        case UP_SIG:
            if (me->timeout__ < MAX_TIMEOUT) {
                ++me->timeout__;
                SetDlgItemInt(locHwnd, IDC_TIMEOUT, me->timeout__, FALSE);
            }
            break;
        case DOWN_SIG:
            if (me->timeout__ > 1) {
                --me->timeout__;
                SetDlgItemInt(locHwnd, IDC_TIMEOUT, me->timeout__, FALSE);
            }
            break;
        case ARM_SIG:
            me->code__ = 0;                   /* invalidate the defuse code */
            QFSM_TRAN(&Bomb_timing);
            break;
    }
}
/*..........................................................................*/
void Bomb_timing(Bomb *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(locHwnd, IDC_STATE, "timing");
            SetTimer(locHwnd, 1, 1000, 0);
            ShowWindow(GetDlgItem(locHwnd, IDC_RED),
                       (me->timeout__ & 1) == 0);
            ShowWindow(GetDlgItem(locHwnd, IDC_YELLOW),
                       (me->timeout__ & 1) != 0);
            break;
        case Q_EXIT_SIG:
            KillTimer(locHwnd, 1);                 /* don't leak the timer! */
            ShowWindow(GetDlgItem(locHwnd, IDC_RED), FALSE);
            ShowWindow(GetDlgItem(locHwnd, IDC_YELLOW), FALSE);
            break;
        case TICK_SIG:
            if (me->timeout__ > 0) {
                --me->timeout__;
                SetDlgItemInt(locHwnd, IDC_TIMEOUT, me->timeout__, FALSE);
                ShowWindow(GetDlgItem(locHwnd, IDC_RED),
                    (me->timeout__ & 1) == 0);
                ShowWindow(GetDlgItem(locHwnd, IDC_YELLOW),
                    (me->timeout__ & 1) != 0);
            }
            else {                                       /* timeout expired */
                QFSM_TRAN(&Bomb_blast);
            }
            break;
        case UP_SIG:
            me->code__ = (me->code__ << 1) | 1;
            break;
        case DOWN_SIG:
            me->code__ <<= 1;
            break;
        case ARM_SIG:
            if (me->code__ == DEFUSE_CODE) {
                QFSM_TRAN(&Bomb_setting);
            }
            else {
                me->code__ = 0;                    /* clear the defuse code */
            }
            break;
    }
}
/*..........................................................................*/
void Bomb_blast(Bomb *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(locHwnd, IDC_STATE, "blast");
            Beep(1000, 20);                              /* make some noise */
            ShowWindow(GetDlgItem(locHwnd, IDC_ARM), FALSE);
            ShowWindow(GetDlgItem(locHwnd, IDC_UP), FALSE);
            ShowWindow(GetDlgItem(locHwnd, IDC_DOWN), FALSE);
            ShowWindow(GetDlgItem(locHwnd, IDC_BLAST), TRUE);
            break;
    }
}
/*--------------------------------------------------------------------------*/
void onAssert__(char const *file, int line) {
    char str[160];
    sprintf(str, "Assertion failed in %s, line %d", file, line);
    MessageBox(locHwnd, str, locAppName, MB_ICONEXCLAMATION | MB_OK);
    exit(-1);
}
/*..........................................................................*/
BOOL CALLBACK BombDlg(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
    BOOL isHandled = TRUE;
    QEvent e;
    e.sig = iMsg;
    switch (iMsg) {
        case WM_INITDIALOG: {
            locHwnd = hWnd;
            SendMessage(hWnd, WM_SETICON, (WPARAM)TRUE,
                        (LPARAM)LoadIcon(locInst, MAKEINTRESOURCE(IDI_QL)));
            QFsmInit((QFsm *)&locApp, 0);    /* take the initial transition */
            return TRUE;
        }
        case WM_TIMER:
            e.sig = TICK_SIG; {
            /* intentionally fall thru */
        }
        case WM_COMMAND: {
            switch (LOWORD(wParam)) {
            case IDCANCEL:
                EndDialog(locHwnd, 0);
                break;
            case IDC_ARM:
                e.sig = ARM_SIG;
                break;
            case IDC_UP:
                e.sig = UP_SIG;
                break;
            case IDC_DOWN:
                e.sig = DOWN_SIG;
                break;
            default:
                isHandled = FALSE;
                break;
            }
            QFsmDispatch((QFsm *)&locApp, &e);       /* dispatch the QEvent */
            return isHandled;
        }
    }
    return FALSE;
}
/*..........................................................................*/
int WINAPI WinMain(HINSTANCE hlocInst, HINSTANCE hPrevlocInst,
                   PSTR cmdLine, int iCmdShow)
{
    InitCommonControls();                   /* load common controls library */
    locInst = hlocInst;                         /* store locInstance handle */
    BombCtor(&locApp);                 /* construct the Bomb locApplication */
    DialogBox(hlocInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, BombDlg);
    return 0;                /* exit locApplication when the dialog returns */
}

