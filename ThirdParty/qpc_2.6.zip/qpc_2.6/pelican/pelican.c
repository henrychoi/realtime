/*****************************************************************************
* Product:  Pedestrian Light Controlled Crossing Example
* Version:  Compatible with QEP/C 2.6.xx
* Released: Dec 27 2003
* Updated:  Dec 17 2004
*
* Copyright (C) 2002-2004 Quantum Leaps. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of the
* GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the terms
* of Quantum Leaps commercial licenses, which are designed for users who want
* to retain proprietary status of their code. This "dual-licensing" model is
* possible because Quantum Leaps owns the copyright to this source code and as
* such can license its intelectual property any number of times. The users who
* license this software under one of Quantum Leaps commercial licenses do not
* use this software under the GPL and therefore are not subject to any of its
* terms.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* Quantum Leaps licensing: http://www.quantum-leaps.com/licensing/overview.htm
* e-mail:                  sales@quatnum-leaps.com
*
*****************************************************************************/
#include <windows.h>
#include <string.h>
#include <commctrl.h>
#include <stdio.h>

#include "qassert.h"
#include "qhsm.h"                 /* Hierarchical State Machine part of QEP */
#include "pelican.h"                                   /* PELICAN resources */

DEFINE_THIS_FILE;

/* Pelican class -----------------------------------------------------------*/
typedef struct Pelican Pelican;
struct Pelican {
    QHsm super_;
    int  pedestrianFlashCtr__;
    HWND hWnd__;
};

Pelican *PelicanCtor(Pelican *me);
void Pelican_initial(Pelican *me, QEvent const *e);
QSTATE Pelican_operational(Pelican *me, QEvent const *e);
QSTATE Pelican_vehiclesEnabled(Pelican *me, QEvent const *e);
QSTATE Pelican_vehiclesGreen(Pelican *me, QEvent const *e);
QSTATE Pelican_vehiclesGreenNoPed(Pelican *me, QEvent const *e);
QSTATE Pelican_vehiclesGreenPedWait(Pelican *me, QEvent const *e);
QSTATE Pelican_vehiclesGreenInt(Pelican *me, QEvent const *e);
QSTATE Pelican_vehiclesYellow(Pelican *me, QEvent const *e);
QSTATE Pelican_pedestriansEnabled(Pelican *me, QEvent const *e);
QSTATE Pelican_pedestriansWalk(Pelican *me, QEvent const *e);
QSTATE Pelican_pedestriansFlash(Pelican *me, QEvent const *e);
QSTATE Pelican_off(Pelican *me, QEvent const *e);

enum VehiclesSignal {
    RED, YELLOW, GREEN
};
enum PedestriansSignal {
    DONT_WALK, BLANK, WALK
};

void Pelican_signalVehicles(Pelican *me, enum VehiclesSignal sig);
void Pelican_signalPedestrians(Pelican *me,
    enum PedestriansSignal sig);

/*--------------------------------------------------------------------------*/
enum PelicanSignals {
    OFF_SIG = Q_USER_SIG,
        PEDESTRIAN_WAITING_SIG,
        TIMEOUT_SIG
};
/*..........................................................................*/
enum PelicanTimeouts {                  /* various timeouts in milliseconds */
    VEHICLES_GREEN_MIN_TOUT = 8000,           /* minimum green for vehicles */
    VEHICLES_YELLOW_TOUT    = 2000,              /* yellow for vehicles */
    PEDESTRIANS_WALK_TOUT   = 4000,         /* walking time for pedestrians */
    PEDESTRIANS_FLASH_TOUT  = 500,            /* flashing interval for ped. */
    PEDESTRIANS_FLASH_NUM   = 3,              /* number of flashes for ped. */
};
/*--------------------------------------------------------------------------*/
static Pelican app;
static HINSTANCE inst;                                     /* this instance */
static HWND mainHwnd;                                    /* the main window */
static char appName[] = "Pelican";

/*..........................................................................*/
Pelican *PelicanCtor(Pelican *me) {
    QHsmCtor_(&me->super_, (QPseudoState)&Pelican_initial);
    return me;
}
/* HSM definition ----------------------------------------------------------*/
void Pelican_initial(Pelican *me, QEvent const *e) {
    SendMessage(me->hWnd__, WM_SETICON, (WPARAM)TRUE,
                (LPARAM)LoadIcon(inst, MAKEINTRESOURCE(IDI_QL)));
    Pelican_signalVehicles(me, RED);
    Pelican_signalPedestrians(me, DONT_WALK);
    Q_INIT(&Pelican_operational);
}
/*..........................................................................*/
QSTATE Pelican_off(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            EndDialog(me->hWnd__, 0);
            return 0;
    }
    return (QSTATE)&QHsm_top;
}
/*..........................................................................*/
QSTATE Pelican_operational(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_INIT_SIG:
            Q_INIT(&Pelican_vehiclesEnabled);
            return 0;
        case OFF_SIG:
            Q_TRAN(&Pelican_off);
            return 0;
    }
    return (QSTATE)&QHsm_top;
}
/*..........................................................................*/
QSTATE Pelican_vehiclesEnabled(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            Pelican_signalPedestrians(me, DONT_WALK);
            return 0;
        case Q_INIT_SIG:
            Q_INIT(&Pelican_vehiclesGreen);
            return 0;
    }
    return (QSTATE)&Pelican_operational;
}
/*..........................................................................*/
QSTATE Pelican_vehiclesGreen(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetTimer(me->hWnd__, 1, VEHICLES_GREEN_MIN_TOUT, 0);
            Pelican_signalVehicles(me, GREEN);
            return 0;
        case Q_INIT_SIG:
            Q_INIT(&Pelican_vehiclesGreenNoPed);
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican_vehiclesGreenInt);
            return 0;
        case Q_EXIT_SIG:
            KillTimer(me->hWnd__, 1);              /* don't leak the timer! */
            return 0;
    }
    return (QSTATE)&Pelican_vehiclesEnabled;
}
/*..........................................................................*/
QSTATE Pelican_vehiclesGreenNoPed(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(me->hWnd__, IDC_STATE, "vehiclesGreenNoPed");
            return 0;
        case PEDESTRIAN_WAITING_SIG:
            Q_TRAN(&Pelican_vehiclesGreenPedWait);
            return 0;
    }
    return (QSTATE)&Pelican_vehiclesGreen;
}
/*.................................................................*/
QSTATE Pelican_vehiclesGreenPedWait(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(me->hWnd__, IDC_STATE, "vehiclesGreenPedWait");
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican_vehiclesYellow);
            return 0;
    }
    return (QSTATE)&Pelican_vehiclesGreen;
}
/*..........................................................................*/
QSTATE Pelican_vehiclesGreenInt(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(me->hWnd__, IDC_STATE, "vehiclesGreenInt");
            return 0;
        case PEDESTRIAN_WAITING_SIG:
            Q_TRAN(&Pelican_vehiclesYellow);
            return 0;
    }
    return (QSTATE)&Pelican_vehiclesEnabled;
}
/*..........................................................................*/
QSTATE Pelican_vehiclesYellow(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(me->hWnd__, IDC_STATE, "vehiclesYellow");
            SetTimer(me->hWnd__, 1, VEHICLES_YELLOW_TOUT, 0);
            Pelican_signalVehicles(me, YELLOW);
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican_pedestriansEnabled);
            return 0;
        case Q_EXIT_SIG:
            KillTimer(me->hWnd__, 1);              /* don't leak the timer! */
            return 0;
    }
    return (QSTATE)&Pelican_vehiclesEnabled;
}
/*..........................................................................*/
QSTATE Pelican_pedestriansEnabled(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            Pelican_signalVehicles(me, RED);
            return 0;
        case Q_INIT_SIG:
            Q_INIT(&Pelican_pedestriansWalk);
            return 0;
    }
    return (QSTATE)&Pelican_operational;
}
/*..........................................................................*/
QSTATE Pelican_pedestriansWalk(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(me->hWnd__, IDC_STATE, "pedestriansWalk");
            Pelican_signalPedestrians(me, WALK);
            SetTimer(me->hWnd__, 1, PEDESTRIANS_WALK_TOUT, 0);
            return 0;
        case TIMEOUT_SIG:
            Q_TRAN(&Pelican_pedestriansFlash);
            return 0;
        case Q_EXIT_SIG:
            KillTimer(me->hWnd__, 1);              /* don't leak the timer! */
            return 0;
    }
    return (QSTATE)&Pelican_pedestriansEnabled;
}
/*..........................................................................*/
QSTATE Pelican_pedestriansFlash(Pelican *me, QEvent const *e) {
    switch (e->sig) {
        case Q_ENTRY_SIG:
            SetDlgItemText(me->hWnd__, IDC_STATE, "pedestriansFlash");
            SetTimer(me->hWnd__, 1, PEDESTRIANS_FLASH_TOUT, 0);
            me->pedestrianFlashCtr__ = PEDESTRIANS_FLASH_NUM*2 + 1;
            return 0;
        case TIMEOUT_SIG:
            if (me->pedestrianFlashCtr__ == 0) {          /* done flashing? */
                Q_TRAN(&Pelican_vehiclesEnabled);
            }
            else if ((me->pedestrianFlashCtr__ & 1) == 0) {    /* even ctr? */
                --me->pedestrianFlashCtr__;
                Pelican_signalPedestrians(me, DONT_WALK);
            }
            else {                                   /* must be odd counter */
                --me->pedestrianFlashCtr__;
                Pelican_signalPedestrians(me, BLANK);
            }
            return 0;
        case Q_EXIT_SIG:
            KillTimer(me->hWnd__, 1);              /* don't leak the timer! */
            return 0;
    }
    return (QSTATE)&Pelican_pedestriansEnabled;
}
/*..........................................................................*/
void Pelican_signalVehicles(Pelican *me, enum VehiclesSignal sig) {
    ShowWindow(GetDlgItem(me->hWnd__, IDC_RED),    sig == RED);
    ShowWindow(GetDlgItem(me->hWnd__, IDC_YELLOW), sig == YELLOW);
    ShowWindow(GetDlgItem(me->hWnd__, IDC_GREEN),  sig == GREEN);
}
/*..........................................................................*/
void Pelican_signalPedestrians(Pelican *me,
    enum PedestriansSignal sig)
{
    ShowWindow(GetDlgItem(me->hWnd__, IDC_DONT_WALK), sig == DONT_WALK);
    ShowWindow(GetDlgItem(me->hWnd__, IDC_BLANK),     sig == BLANK);
    ShowWindow(GetDlgItem(me->hWnd__, IDC_WALK),      sig == WALK);
}
/*..........................................................................*/
void onAssert__(char const *file, int line) {
    char str[160];
    sprintf(str, "Assertion failed in %s, line %d", file, line);
    MessageBox(mainHwnd, str, appName, MB_ICONEXCLAMATION | MB_OK);
    exit(-1);
}
/*--------------------------------------------------------------------------*/
BOOL CALLBACK PelicanDlg(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam) {
    QEvent e;
    e.sig = iMsg;
    switch (iMsg) {
        case WM_INITDIALOG: {
            app.hWnd__ = mainHwnd = hwnd;
            QHsmInit((QHsm *)&app, 0);       /* take the initial transition */
            return TRUE;
        }
        case WM_TIMER: {
            e.sig = TIMEOUT_SIG;
            /* intentionally fall thru */
        }
        case WM_COMMAND: {
            switch (LOWORD(wParam)) {
            case IDCANCEL:
                e.sig = OFF_SIG;
                break;
            case IDC_PEDESTRIAN_WAITING:
                e.sig = PEDESTRIAN_WAITING_SIG;
                break;
            }
            QHsmDispatch((QHsm *)&app, &e);           /* dispatch the event */
            return TRUE;
        }
    }
    return FALSE;
}
/*..........................................................................*/
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst,
                   PSTR cmdLine, int iCmdShow)
{
    InitCommonControls();                   /* load common controls library */
    inst = hInst;                                  /* store instance handle */
    PelicanCtor(&app);                 /* construct the Pelican application */
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, PelicanDlg);
    return 0;                   /* exit application when the dialog returns */
}

